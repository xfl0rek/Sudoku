module ModelProject {
    requires org.apache.commons.lang3;

    exports pl.sudoku;
}