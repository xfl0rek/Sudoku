package pl.sudoku;

public class SudokuBox extends SudokuVerify {
    SudokuBox(SudokuField[] sudokuFields) {
        super(sudokuFields);
    }
}
