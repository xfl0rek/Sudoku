package pl.sudoku;

public class SudokuRow extends SudokuVerify {
    SudokuRow(SudokuField[] sudokuFields) {
        super(sudokuFields);
    }
}
