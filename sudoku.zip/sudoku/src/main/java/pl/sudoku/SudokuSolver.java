package pl.sudoku;

public interface SudokuSolver {
    void solve(SudokuBoard sudokuBoard);
}
