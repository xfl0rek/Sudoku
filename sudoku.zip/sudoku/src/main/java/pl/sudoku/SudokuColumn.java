package pl.sudoku;

import java.util.List;

public class SudokuColumn extends SudokuVerify {
    SudokuColumn(List<SudokuField> sudokuFields) {
        super(sudokuFields);
    }
}
