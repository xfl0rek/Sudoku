package pl.sudoku;

public class SudokuColumn extends SudokuVerify {
    SudokuColumn(SudokuField[] sudokuFields) {
        super(sudokuFields);
    }
}
